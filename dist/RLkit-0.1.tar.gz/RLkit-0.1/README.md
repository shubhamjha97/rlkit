# A simple agent trained to play LunarLander using Policy Gradients

This project is still a work in progress. More algorithms and detailed documentation coming soon :)

To run the code-
```
python3 main.py
```

Requirements-
```
gym==0.10.5
matplotlib==2.2.3
tensorflow==1.6.0
```