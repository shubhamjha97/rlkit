class GeneralizedPolicyIteration:
	def __init__():
		pass
	